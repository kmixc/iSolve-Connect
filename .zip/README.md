# HOW TO START APP
To start the Application, go to cd frontend and npm start through there
package json in frontend starts both server.js and React using "concurrent" API
